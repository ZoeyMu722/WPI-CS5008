#include <stdlib.h> // Rand/srand
#include <stdio.h> // printf
#include <string.h> // memset
#include <sys/types.h> // pid_t
#include <unistd.h> // fork, getpid
#include <sys/wait.h> // waitpid

int main() {
  char buffer[100];
  FILE *seedFile;
  unsigned int seedValue = 0;
  int randomChildCount = 0;
  int randomWaitValue = 0;
  int randomChildrenNumbers[15];
  
  memset(buffer, 0x00, 100);// Zoey: clear memory buffer before reading
  // chatGPT: ensures no leftover data before reading from seed file
  seedFile = fopen("seed.txt", "r");// Zoey: open seed file for reading
  fgets(buffer, 99, seedFile);// Zoey: read up to 99 chars from file
  fclose(seedFile); // Zoey: close seed file after reading

  // Convert seed value to an integer:
  seedValue = atoi(buffer);
  srand(seedValue);
  // Zoey: initialize random seed for reproducible results
  // chatGPT: seeds the pseudo-random number generator (man 3 rand)
  randomChildCount = (rand() % 6) + 8; 
  // Zoey: generate number of children between 8 and 13
  // chatGPT: modulo limits range; +8 adds base offset

  printf("Read seed value: %s\n", buffer);
  printf("Read seed value (converted to integer): %d\n", seedValue);
  printf("Random Child Count: %d\n", randomChildCount);
  printf("I'm feeling prolific!\n");
  
  for (int i = 0; i < randomChildCount; ++i) {
    randomChildrenNumbers[i] = rand();
    // Zoey: pre-generate random numbers for this iteration
    pid_t forkValue = fork();
    // Zoey: create a new process
    // chatGPT: duplicates current process; 0 in child, PID in parent
    if (forkValue == 0) {
      int randomExitCode = 0;
      pid_t myPID = getpid();
      randomWaitValue = (randomChildrenNumbers[i] % 3) + 1;// Zoey: 1–3 seconds
      randomExitCode = (randomChildrenNumbers[i] % 50) + 1;// Zoey: 1–50 exit code
      printf("   [Child, PID: %d]: I am the child and I will wait %d seconds and exit with code %d.\n", myPID, randomWaitValue, randomExitCode);
      sleep(randomWaitValue);// chatGPT: simulate work delay
      printf("   [Child, PID: %d]: Now exiting...\n", myPID);
      exit(randomExitCode);
      // Zoey: end child process and return code to parent
      // chatGPT: terminates current process image (man 3 exit)
    } else if (forkValue < 0) {
      printf("[ERROR] An error occurred. Exiting!\n");
      return -1;
      // chatGPT: fork() failed, likely resource exhaustion
    } else {
      int waitStatus = 0;
      printf("[Parent]: I am waiting for PID %d to finish.\n", forkValue);
      waitpid(forkValue, &waitStatus, 0);
      // Zoey: block until this specific child ends
      // chatGPT: waitpid(pid, …) waits for given PID; 0 = blocking
      printf("[Parent]: Child %d finished with status code %d. Onward!\n", forkValue, WEXITSTATUS(waitStatus));
      // chatGPT: WEXITSTATUS extracts low-order 8 bits
    }
  }  
  return 0;
}


/*Appendix

prompts:
Refactor my C comments for accuracy and clarity. Keep code identical.  
Verify every claim with man 2 fork, man 2 waitpid, man 3 srand/rand, and man 3 exit.  
If my comment is imprecise, propose a correct replacement and cite the relevant man page.  
Do not fabricate behavior; clarify only what is confirmed by official documentation.  

Also explain:  
– Why the exit code is restricted to 1–50 (range choice and system safety).  
– What a seed actually controls in rand()/srand(), and why different seed values (12321, 98765, 55555, etc.) cause distinct process behavior.  



Man page citations
1.fork()	
man 2 fork	
Returns 0 to the child and child PID to the parent. Duplicates the calling process.
2.waitpid()	
man 2 waitpid	
When the options argument is 0, the call blocks until the specified child terminates. The status integer receives encoded termination info.
3.WEXITSTATUS()	
man 2 wait	
Extracts the low-order 8 bits of the exit status value stored by waitpid().
4.srand() / rand()	
man 3 rand	srand(seed) 
initializes the PRNG; rand() returns a deterministic sequence 0 ≤ x ≤ RAND_MAX based on that seed.
5.exit()	
man 3 exit	
Terminates the calling process and returns its status code to the parent or init process.


Reflection:
The AI’s discussion of random seeds is also more systematic, linking determinism and reproducibility to pseudo-random generator state. 
While my draft was conceptually correct, the AI language was more academic and precise ( e.g., "waitpid(pid, …) waits for given PID; 
0 = blocking” ). However, I still chose to retain some of my own colloquial phrasing to preserve readability for non-experts. Overall,
 the AI did not change the meaning of my explanations but refined their accuracy and depth. The collaboration demonstrated that AI is
a useful editor for clarity and pedagogical tone when paired with human judgment for contextual truthfulness.*/