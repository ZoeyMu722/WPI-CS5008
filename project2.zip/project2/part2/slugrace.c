#include <stdlib.h> // Rand/srand
#include <stdio.h> // printf
#include <string.h> // memset
#include <sys/types.h> // pid_t
#include <unistd.h> // fork, getpid
#include <sys/wait.h> // waitpid
#include <time.h> // clock_gettime() function
/*chatGPT: *slugrace.c
This program demonstrates process-based concurrency using fork(), execvp(), and waitpid().
It simulates a "race" among four child processes, each running the ./slug program.*/

int main(int argc, char *argv[]) {
  char *numbers[] = {"1", "2", "3", "4"};
  pid_t children[4] = {0};

  struct timespec start, now;
  clock_gettime(CLOCK_REALTIME, &start); // Zoey: record the start time of the "race"
  // chatGPT: Record wall-clock start time of the race

  int active_children = 0;
  
  for (int i = 0; i < 4; ++i) {
    pid_t forkValue = fork(); // Zoey: create a new process; duplicates the current one
    // chatGPT: Create a new process; child gets 0, parent gets child's PID.
    if (forkValue == 0) {
      pid_t myPID = getpid();
      char * const arguments[] = {"slug", numbers[i], NULL};
      printf("   [Child, PID: %d]: Executing './slug %s' command...\n", myPID, numbers[i]);
      // Zoey: execvp() replaces current process with a new program (slug)
      // Zoey: It only returns if execution fails.
      // chatGPT: execvp() does NOT create a new process; it replaces the current child image with ./slug.
      int success = execvp("./slug", arguments);
      if (success == -1) {
	printf("   [Child, PID: %d]: Fatal error while executing!\n", myPID);
	exit(-1);
      }
    } else if (forkValue < 0) {
      printf("[ERROR] An error occurred. Exiting!\n");
      return -1;
    } else {
      printf("[Parent]: I forked off child %d.\n", forkValue);
      children[i] = forkValue;
      ++active_children;// Zoey: active_children = active_children + 1;
      // chatGPT: Increase active child count
    }
  }

  while (active_children > 0) {
    int waitStatus = 0;
    pid_t waitReturn = waitpid(-1, &waitStatus, WNOHANG);
    // Zoey: waitpid(-1, …, WNOHANG) means:
    // Zoey:   - Wait for any child (-1)
    // Zoey:   - Non-blocking mode (WNOHANG)
    // Zoey:   - Returns immediately if no child has terminated
    // chatGPT:  Used in a polling loop to check which child (if any) has finished without blocking the parent.

    if (waitReturn == -1) {
      // Error occurred during wait
      printf("An error occurred waiting!\n");
      exit(-1);
    } else if (waitReturn == 0) {
      //Zoey: No child finished yet; print current active children
      printf("The race is ongoing. The following children are still racing: ");
      for (int i = 0; i < 4; ++i) {
	if (children[i] != 0) {
    
	  printf("%d ", children[i]);
	}
      }
      printf("\n");
      usleep(330000); // Zoey: short sleep to avoid busy-waiting

    } else {  // Zoey: A child has finished
      clock_gettime(CLOCK_REALTIME, &now);
      double elapsed = (now.tv_sec - start.tv_sec) + ((now.tv_nsec - start.tv_nsec) / 1000000000);// Zoey: make second as the unit
      // chatGPT: elapsed time in seconds (convert nanoseconds to fractional seconds)

      printf("Child %d has crossed the finish line! It took %f seconds\n", waitReturn, elapsed);
      --active_children;
      // Zoey: Mark the finished child as inactive
      for (int i = 0; i < 4; ++i) {
	if (children[i] == waitReturn) {
	  children[i] = 0;
	}
      }
    }
  }
  // Zoey: Final race summary
  // chatGPT: Final race summary: all children have finished; compute total race time and exit.
  clock_gettime(CLOCK_REALTIME, &now);
  double elapsed = (now.tv_sec - start.tv_sec) + ((now.tv_nsec - start.tv_nsec) / 1000000000);
  printf("The race is over! It took %f seconds\n", elapsed);
    
  return 0;
}

/*Appendix

prompts:
Make my C comments accurate and clear. Keep code identical.
Verify every claim with man 2 fork, man 2 waitpid, and man 3 srand/rand.
If my comment is imprecise, propose a correct replacement.
Do not fabricate behavior; cite which man page clarified changes.




Man page citations:

1.fork()	
man 2 fork	
“In the parent, fork() returns the PID of the child; in the child, it returns 0.”
2.waitpid()	
man 2 waitpid	
“If WNOHANG is specified and no child has exited, waitpid() returns 0 immediately.”
3.clock_gettime()	
man 2 clock_gettime	
“CLOCK_REALTIME is a system-wide clock that measures real (wall-clock) time.”
4.execvp()	
man 3 exec	
“execvp() replaces the current process image with a new process image.”
5.srand()/rand()	
man 3 rand	
“The srand() function seeds the pseudo-random number generator used by rand().”




Reflection:
Using AI to refine my manual comments is helpful for clarifying technical precision and terminology.
In my initial annotations, I described fork() as “creating a new thread-like process,” but the AI correction—confirmed with man 2 fork—explained that it duplicates the entire process image and returns different values to parent and child. These adjustments made my comments more accurate and conceptually aligned with UNIX semantics.
AI also helped summarize the difference between blocking and non-blocking waitpid() calls by linking WNOHANG to periodic polling loops, which I verified in man 2 waitpid.
However, AI tended to overstate details about “real-time scheduling” and “CPU fairness,” which were not relevant to this lab’s scope. Those claims were removed after checking the manual.
Overall, AI was useful for rephrasing and precision, but manual validation with man pages remained essential to avoid false confidence. The combination of AI drafting and human verification led to clearer, more trustworthy documentation of process management behavior.*/