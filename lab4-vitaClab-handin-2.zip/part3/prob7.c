#include <stdio.h>
#include <stdlib.h>
#include <string.h>


long convertToSeconds(char *date, char *time) {
    int year, month, day, hour, minute, second;
    sscanf(date, "%d_%d_%d", &year, &month, &day);
    sscanf(time, "%d:%d:%d", &hour, &minute, &second);
    return (long)((year * 365 + month * 30 + day) * 86400
                  + hour * 3600 + minute * 60 + second);
}


double calcSlope(char *startDate, char *startTime,
                 char *endDate, char *endTime) {
    char *files[] = {
        "Environmental_Data_Deep_Moor_2012.txt",
        "Environmental_Data_Deep_Moor_2013.txt",
        "Environmental_Data_Deep_Moor_2014.txt",
        "Environmental_Data_Deep_Moor_2015.txt"
    };
    int numFiles = 4;

    char date[20], time[20];
    double airT, bp, dew, rh, wd, wg, ws;
    long x1 = -1, x2 = -1;
    double y1 = 0.0, y2 = 0.0;

    long startSec = convertToSeconds(startDate, startTime);
    long endSec   = convertToSeconds(endDate, endTime);

    for (int f = 0; f < numFiles; f++) {
        FILE *fp = fopen(files[f], "r");
        if (!fp) {
            printf("Error: Could not open %s\n", files[f]);
            continue;
        }

        while (fscanf(fp, "%s %s %lf %lf %lf %lf %lf %lf %lf",
                      date, time, &airT, &bp, &dew, &rh, &wd, &wg, &ws) == 9) {
            long curSec = convertToSeconds(date, time);

            if (curSec == startSec && x1 == -1) {
                x1 = curSec;
                y1 = bp;
            }
            if (curSec == endSec) {
                x2 = curSec;
                y2 = bp;
            }
        }
        fclose(fp);
    }

    if (x1 == -1 || x2 == -1 || x1 == x2) {
        printf("Error: could not find valid start/end points in data.\n");
        return 0.0;
    }

    return (y2 - y1) / (x2 - x1);
}

int main() {
    char startDate[20], startTime[20];
    char endDate[20], endTime[20];

    printf("Enter start date (YYYY_MM_DD): ");
    scanf("%s", startDate);
    printf("Enter start time (HH:MM:SS): ");
    scanf("%s", startTime);

    printf("Enter end date (YYYY_MM_DD): ");
    scanf("%s", endDate);
    printf("Enter end time (HH:MM:SS): ");
    scanf("%s", endTime);

    double slope = calcSlope(startDate, startTime, endDate, endTime);

    if (slope > 0)
        printf("Slope = %lf -> Rising pressure, fair weather.\n", slope);
    else if (slope < 0)
        printf("Slope = %lf -> Falling pressure, stormy weather.\n", slope);
    else
        printf("Slope = %lf -> No significant change.\n", slope);

    return 0;
}

