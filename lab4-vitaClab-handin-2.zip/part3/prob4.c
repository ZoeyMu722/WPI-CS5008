#include <stdio.h>

int main() {
    int x;
    int binary[32];  
    int index = 0;

    printf("Enter a positive integer: ");
    scanf("%d", &x);

    if (x <= 0) {
        printf("Please enter a positive integer.\n");
        return 1;
    }

   
    while (x > 0) {
        binary[index++] = x % 2;
        x = x / 2;
    }

    printf("Binary: ");
    
    for (int i = index - 1; i >= 0; i--) {
        printf("%d", binary[i]);
    }
    printf("\n");

    return 0;
}

