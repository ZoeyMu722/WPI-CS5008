#include <stdio.h>

int main() {
    int n;
    double values[20];  
    double max;

    scanf("%d", &n);

    if (n <= 0 || n > 20) {
        printf("Invalid input size.\n");
        return 1;
    }

    
    scanf("%lf", &values[0]);
    max = values[0];

    
    for (int i = 1; i < n; i++) {
        scanf("%lf", &values[i]);
        if (values[i] > max) {
            max = values[i];
        }
    }

 
    for (int i = 0; i < n; i++) {
        printf("%.2lf", values[i] / max);
        if (i < n - 1) printf(" "); 
    }
    printf("\n");

    return 0;
}
