#include <stdio.h>

int main() {
    int n, i, count;

    while (1) {
        printf("Enter a number (0 to quit): ");
        scanf("%d", &n);

        if (n == 0)
            break;

        count = 0;

        for (i = 1; i <= n; i++) {
            if (n % i == 0) {
                count++;
            }
        }

        if (count == 2)
            printf("%d is prime\n", n);
        else
            printf("%d is not prime\n", n);
    }
    return 0;
}
