#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX 10000       
#define LINESIZE 2048   


struct listing {
    int id, host_id, minimum_nights, number_of_reviews,
        calculated_host_listings_count, availability_365;
    char *host_name, *neighbourhood_group, *neighbourhood, *room_type;
    float latitude, longitude, price;
};


void get_fields(char *line, struct listing *item) {
    item->id = atoi(strtok(line, ","));
    item->host_id = atoi(strtok(NULL, ","));
    item->host_name = strdup(strtok(NULL, ","));
    item->neighbourhood_group = strdup(strtok(NULL, ","));
    item->neighbourhood = strdup(strtok(NULL, ","));
    item->latitude = atof(strtok(NULL, ","));
    item->longitude = atof(strtok(NULL, ","));
    item->room_type = strdup(strtok(NULL, ","));
    item->price = atof(strtok(NULL, ","));
    item->minimum_nights = atoi(strtok(NULL, ","));
    item->number_of_reviews = atoi(strtok(NULL, ","));
    item->calculated_host_listings_count = atoi(strtok(NULL, ","));
    item->availability_365 = atoi(strtok(NULL, ","));
}


void displayStruct(struct listing item) {
    printf("ID:%d | Host:%s | Price:%.2f | Neighbourhood:%s | Room:%s\n",
           item.id,
           item.host_name,
           item.price,
           item.neighbourhood,
           item.room_type);
}


int cmp_host_name(const void *a, const void *b) {
    struct listing *ia = (struct listing *)a;
    struct listing *ib = (struct listing *)b;
    return strcmp(ia->host_name, ib->host_name);
}


int cmp_price(const void *a, const void *b) {
    struct listing *ia = (struct listing *)a;
    struct listing *ib = (struct listing *)b;
    if (ia->price < ib->price) return -1;
    if (ia->price > ib->price) return 1;
    return 0;
}

int main() {
    char line[LINESIZE];
    struct listing items[MAX];
    int count = 0;

    
    fgets(line, LINESIZE, stdin);

  
    while (fgets(line, LINESIZE, stdin) != NULL) {
        get_fields(line, &items[count++]);
    }

  
    printf("\n--- Sorted by Host Name ---\n");
    qsort(items, count, sizeof(struct listing), cmp_host_name);
    for (int i = 0; i < count; i++) {
        displayStruct(items[i]);
    }

    
    printf("\n--- Sorted by Price ---\n");
    qsort(items, count, sizeof(struct listing), cmp_price);
    for (int i = 0; i < count; i++) {
        displayStruct(items[i]);
    }

    return 0;
}
