#include <stdio.h>
#include <string.h>
#include <stdlib.h>


int createarray(char *line, char *aptr[]) {
    int count = 0;
    char *token = strtok(line, " ");   
    while (token != NULL) {
        aptr[count++] = token;         
        token = strtok(NULL, " ");     
    }
    aptr[count] = NULL;                
    return count;
}

int main() {
    char line[100] = "CS5008 Lab Debugging and IO";
    char *aptr[20];
    int n = createarray(line, aptr);

    printf("Total tokens: %d\n", n);
    for (int i = 0; i < n; i++) {
        printf("Token[%d]: %s\n", i, aptr[i]);
    }

    return 0;
}
