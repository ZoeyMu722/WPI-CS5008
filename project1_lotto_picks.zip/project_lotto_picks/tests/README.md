# Lotto Picks – Testing Suite  
**Authors:** Zongyu Mu & Nicholas Sirota  
**Course:** CS5008 – Introduction to Systems and Network Programming  
**Date:** October 17, 2025  

This folder contains the test suite for Big Question 2, including black-box and white-box tests for validating the correctness and behavior of the Lotto and Odds programs.



## Big Question 2A: Black-Box Tests

### test_lotto_uniqueness.c
This program runs the simulated `lotto()` function 10,000 times and checks that:
- Each draw contains **exactly 5 numbers**  
- Each number lies **within [1, 69]**  
- **No duplicates** appear within any draw  
It uses `assert()` to automatically validate correctness for every iteration.  
If all checks pass, the output will display:
test_lotto_uniqueness passed all 10,000 draws.
**Key Concepts Tested:** randomness range, uniqueness, and output stability



### test_odds_inputs.c
This test validates the **input verification logic** from `odds03.c`.
A helper function `check_inputs(items, draw)` returns:
- `0` → valid inputs  
- `1` → invalid inputs  
| Input (items, draw) | Expected Result    | Description         |
|---------------------|--------------------|---------------------|
| (69, 5)             | ✅ Valid          | Typical Lotto case  |
| (10, 12)            | ❌ Invalid        | draw > items        |
| (0, 5)              | ❌ Invalid        | items = 0           |
| (5, 0)              | ❌ Invalid        | draw = 0            |
If all assertions succeed, the output will display:
test_odds_inputs passed all input validation checks.
**Key Concepts Tested:** logical input validation and boundary handling


## Big Question 2B: White-Box Probes
These internal probes were designed after examining the implementation of `lotto01.c` and `lotto03.c`.  
They confirm that the program’s internal behavior matches the design intent.

### Determinism Probe
**Goal:** Verify that pseudo-random number generation behaves deterministically when seeded consistently.
**Method:**
- Run `lotto01.c` twice with `srand(1)` → both runs must produce identical sequences  
- Run again with `srand((unsigned)time(NULL))` → output should differ each time
**Expected Observation:**
Run 1 (fixed seed): 23 44 9 16 28 Run 2 (fixed seed): 23 44 9 16 28 Run 3 (time seed): 12 55 42 68 31
✅ Result: Fixed seeds produce identical draws; time-based seeds vary → randomness correctly implemented

### Sorting / Formatting Probe
**Goal:** Ensure single-line formatted output from `lotto03.c` is sorted and duplicate-free.
**Example Output:**
12 - 18 - 29 - 44 - 66
**Verification Logic:**
1. Parse the line by `"-"` delimiters  
2. Convert each token to integer  
3. Assert that:  
   - There are exactly **5 numbers**  
   - Each number is **strictly increasing**  
   - No duplicate values appear
✅ Result: All conditions hold → output is properly formatted and ordered



## Big Question 2C: Copilot-Assisted Test Generation

Using **GitHub Copilot Labs → “Generate Tests”** inside VS Code, we requested test case suggestions for the Lotto and Odds modules.
### What Copilot Suggested
- Initially proposed using external testing frameworks (`cmocka`, `unity`)  
- These were removed to comply with project constraints
### What We Kept
- Pure C implementations using `<assert.h>` only  
- Random draw tests (`test_lotto_uniqueness.c`)  
- Input validation tests (`test_odds_inputs.c`)  
All selected Copilot-generated and manually refined tests compiled cleanly under `gcc -Wall -g`, and passed every run without warnings



## Compilation & Execution Guide
Run the following commands from the project root directory:
# Build and run the Lotto uniqueness test
gcc -Wall -g tests/test_lotto_uniqueness.c -o test_lotto_uniqueness
./test_lotto_uniqueness
# Build and run the Odds input validation test
gcc -Wall -g tests/test_odds_inputs.c -o test_odds_inputs
./test_odds_inputs

Expected Output:
✅ test_lotto_uniqueness passed all 10,000 draws.
✅ test_odds_inputs passed all input validation checks.

All tests rely solely on:
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <time.h>
No external testing frameworks are required.