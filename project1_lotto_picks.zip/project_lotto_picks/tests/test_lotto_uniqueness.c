// Test template: verify no duplicate draws

/*
 * File: test_lotto_uniqueness.c
 * Author: Zongyu Mu
 * Partner: Nicholas Sirota
 * Purpose: Black-box test to ensure lotto() produces valid, unique draws.
 * Date: 2025-10-17
 */

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <time.h>

#define BALLS 69
#define DRAW 5

/*
 * Simulated lotto() function using the availability-array approach
 * as implemented in lotto04.c / lotto03.c.
 */
void lotto(int *a) {
    int numbers[BALLS] = {0};
    int r, count = 0;

    while (count < DRAW) {
        r = rand() % BALLS;
        if (numbers[r] == 0) {
            numbers[r] = 1;
            *(a + count) = r + 1; // store 1-based numbers
            count++;
        }
    }
}

int main() {
    int draw[DRAW];
    srand((unsigned)time(NULL));  // seed random generator

    for (int t = 0; t < 10000; t++) {
        lotto(draw);

        // Check range
        for (int i = 0; i < DRAW; i++) {
            assert(draw[i] >= 1 && draw[i] <= BALLS);
        }

        // Check duplicates
        for (int i = 0; i < DRAW; i++) {
            for (int j = i + 1; j < DRAW; j++) {
                assert(draw[i] != draw[j]);
            }
        }

        // Check total count
        int count = 0;
        for (int i = 0; i < DRAW; i++) count++;
        assert(count == DRAW);
    }

    printf("✅ test_lotto_uniqueness passed all 10,000 draws.\n");
    return 0;
}
