// Test template: verify invalid input cases

/*
 * File: test_odds_inputs.c
 * Author: Zongyu Mu
 * Partner: Nicholas Sirota
 * Purpose: Black-box test to validate input rules in odds03.c
 * Date: 2025-10-17
 */

#include <stdio.h>
#include <assert.h>

/*
 * Simplified odds03-style input validation function.
 * Returns 0 if valid, 1 if invalid (mimics error message path).
 */
int check_inputs(int items, int draw) {
    if (items <= 0 || draw <= 0 || draw > items)
        return 1; // invalid
    return 0; // valid
}

int main() {
    printf("Running test_odds_inputs...\n");

    // Valid input
    assert(check_inputs(69, 5) == 0);

    // draw > items
    assert(check_inputs(10, 12) == 1);

    // items = 0
    assert(check_inputs(0, 5) == 1);

    // draw = 0
    assert(check_inputs(5, 0) == 1);

    printf("✅ test_odds_inputs passed all input validation checks.\n");
    return 0;
}
