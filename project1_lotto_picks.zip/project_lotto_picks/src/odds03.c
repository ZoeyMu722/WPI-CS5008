#include <stdio.h>

int main()
{
    int items, draw, x;
    unsigned long long i, d;          /* 1 */

    printf("Number of items: ");
    scanf("%d", &items);
    printf("Items to draw: ");
    scanf("%d", &draw);

    i = items;
    d = draw;

    if (items <= 0 || draw <= 0 || draw > items) {
    printf("Invalid input. Ensure items > 0, draw > 0, and draw ≤ items.\n");
    return 1;
    }
    
    for (x = 1; x < draw; x++)        /* 2 */
    {
        i *= items - x;               /* 3 */
        d *= draw - x;                /* 4 */
    }
   

    printf("Your odds of drawing %d ", draw);
    printf("items from %d are:\n", items);
    printf("\t1:%.0f\n", (float)i / (float)d);   /* 5 */

    return (0);
}
