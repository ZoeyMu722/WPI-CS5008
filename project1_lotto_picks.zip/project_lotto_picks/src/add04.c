#include <stdio.h>
#include <string.h>

void commify(unsigned long n, char *out) {
    char buffer[30];
    sprintf(buffer, "%lu", n);

    int len = strlen(buffer);
    int commas = (len - 1) / 3;
    int newlen = len + commas;
    out[newlen] = '\0';

    for (int i = len - 1, j = newlen - 1, count = 0; i >= 0; i--, j--) {
        out[j] = buffer[i];
        count++;
        if (count == 3 && i != 0) {
            j--;
            out[j] = ',';
            count = 0;
        }
    }
}

int main() {
    int items, draw, x;
    unsigned long long i, d;

    printf("Number of items: ");
    scanf("%d", &items);
    printf("Items to draw: ");
    scanf("%d", &draw);

    if (items <= 0 || draw <= 0 || draw > items) {
        printf("Invalid input. Ensure items > 0, draw > 0, and draw ≤ items.\n");
        return 1;
    }

    i = items;
    d = draw;

    for (x = 1; x < draw; x++) {
        i *= items - x;
        d *= draw - x;
    }

    char formatted[32];
    commify((unsigned long)((float)i / (float)d), formatted);

    printf("Your odds of drawing %d items from %d are:\n", draw, items);
    printf("\t1:%s\n", formatted);

    return 0;
}
