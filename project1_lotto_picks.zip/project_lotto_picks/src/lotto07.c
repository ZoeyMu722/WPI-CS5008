#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define BALLS 69
#define DRAW 5
// Using the availability array method 
void lotto(int *a) {
    int numbers[BALLS] = {0};
    int x, r, c = 0;

    for (x = 0; x < DRAW; x++) {
        r = rand() % BALLS;
        while (numbers[r] == 1) { //controlled bug, changed 1 -> 0 
            r = rand() % BALLS; // this rerolls if already drawn 
        }
        numbers[r] = 1;
    }

    for (x=0; x < BALLS; x++) {
        if (numbers[x] == 1) {
            *(a + c) = x + 1;
            c++;
            if (c == DRAW)
                break;
        }
    }
}

int winner(int *m, int *g) {
    int x, y, count = 0;

    for (x = 0; x < DRAW; x++) {
        for (y = 0; y < DRAW; y++) {
            if (*(m + x) == *(g + y)) {
                count++;
            }
        }
    }
    
    return count;
}
// prints the ticket in a format 
void print_ticket(int *a) {
    int x; 
    for (x = 0; x < DRAW; x++) {
        printf("%02d", *(a + x));
        if (x < DRAW - 1) {
            printf("-"); // adding a seperator 
        }
    }
    printf("\n");
}

int main() {
    int my_ticket[DRAW];
    int guess_ticket[DRAW];
    int matches; 

    srand((unsigned)time(NULL));

    lotto(my_ticket);
    lotto(guess_ticket);

    printf("Your ticket: ");
    print_ticket(my_ticket);
    printf("Guess: ");
    print_ticket(guess_ticket);

    matches = winner(my_ticket, guess_ticket);
    printf("Matches: %d\n", matches);

    return 0;
}