#include <stdio.h>
#include <stdlib.h> 
#include <time.h>   

#define BALLS 69
#define DRAW 5

// lotto function from 7
void lotto(int *a) {
    int numbers[BALLS] = {0};
    int x, r, c = 0;

    for (x = 0; x < DRAW; x++) {
        r = rand() % BALLS;
        while (numbers[r] == 1) {
            r = rand() % BALLS;
        }
        numbers[r] = 1;
    }

    for (x = 0; x < BALLS; x++) {
        if (numbers[x] == 1) {
            *(a + c) = x + 1;
            c++;
            if (c == DRAW)
                break;
        }
    }
}

// winner function from 7
int winner(int *m, int *g) {
    int x, y, count = 0;
    for (x = 0; x < DRAW; x++) {
        for (y = 0; y < DRAW; y++) {
            if (*(m + x) == *(g + y)) {
                count++;
            }
        }
    }
    return count;
}

// print ticket function from 7
void print_ticket(int *a) {
    int x;
    for (x = 0; x < DRAW; x++) {
        printf("%02d", *(a + x));
        if (x < DRAW - 1) {
            printf("-");
        }
    }
    printf("\n");
}
// Loops until 'tomatch' numbers are guessed correctly. 
int main() {
    int my_ticket[DRAW];
    int guess_ticket[DRAW];
    int matches = 0;

    int tomatch = 5; 
    
    // 'tries' must be very large, so use long long
    long long tries = 0;

    srand((unsigned)time(NULL));

    lotto(my_ticket);
    printf("Your ticket: ");
    print_ticket(my_ticket);
    printf("Matching %d numbers\n", tomatch);

    do {
        lotto(guess_ticket); 
        matches = winner(my_ticket, guess_ticket);
        tries++;

    } while (matches < tomatch);

    printf("It took %lld tries to match %d numbers.\n", tries, tomatch);
    printf("Winning guess: ");
    print_ticket(guess_ticket);

    return 0;
}