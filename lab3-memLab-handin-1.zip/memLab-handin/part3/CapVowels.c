#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

// Return a newly allocated copy of original
// with the first occurrence of each vowel capitalized
char* CapVowels(char* original) {
    char* newstr = malloc(strlen(original) + 1);
    strcpy(newstr, original);

    int found[5] = {0}; // Track a, e, i, o, u

    for(int i = 0; newstr[i]; i++) {
        switch(tolower(newstr[i])) {
            case 'a':
                if(!found[0]) { newstr[i]='A'; found[0]=1; }
                break;
            case 'e':
                if(!found[1]) { newstr[i]='E'; found[1]=1; }
                break;
            case 'i':
                if(!found[2]) { newstr[i]='I'; found[2]=1; }
                break;
            case 'o':
                if(!found[3]) { newstr[i]='O'; found[3]=1; }
                break;
            case 'u':
                if(!found[4]) { newstr[i]='U'; found[4]=1; }
                break;
        }
    }

    return newstr;
}

int main(void) {
    char userCaption[50];
    char* resultStr;

    printf("Enter a string: ");
    scanf("%s", userCaption);

    resultStr = CapVowels(userCaption);

    printf("Original: %s\n", userCaption);
    printf("Modified: %s\n", resultStr);

    free(resultStr);
    return 0;
}

