#include <string.h>
#include "student.h"

struct student_info make_student(void){
   struct student_info me;

   me.lucky_number = 7; /*apparently in many cultures*/
   strcpy(me.name,"Zongyu Mu");
   strcpy(me.birthplace,"Dunhua,Jilin,China");
   me.semesters = 0;
   strcpy(me.class_goal,"I want to learn C programming and get a good grade.");
   strcpy(me.reason_cs, "I am interested in programming and want to gain high salary.");
   strcpy(me.hardest_program,"CS584");
   strcpy(me.hobby,"I like reading mystery novels.");
   strcpy(me.s_goals, "What is the meaning of goals, eh?"); /* strcpy is necessary to copy a string */

   strcpy(me.m_goals, "I gotta do something by then");

   strcpy(me.lt_goals, "Gosh, I am absolutely clueless what I am going to do then. Sigh!");

   return me;
}
