/* part2.c -- This is part 2 of introlab for CS 5008 */

#include <stdio.h>
#include "student.h"

int main()
{
 /* create a struct of type student_info called student */
 /* then call the make_student() function from student.c
  * to fill it with information */
  struct student_info student = make_student(); 

  /* Now start printing out what's stored in student.
   * \n represents the newline character
   * %d is for substituting integer values  */
  printf ("Your lucky number is: %d\n\n", student.lucky_number);
  printf ("Student Name: %s\n",student.name);
  printf ("Place of Birth: %s\n",student.birthplace);
  printf ("Semesters at WPI: %d\n",student.semesters);
  printf ("Class Goal: %s\n", student.class_goal);
  printf ("Reason for CS: %s\n",student.reason_cs);
  printf ("Hobby: %s\n",student.hobby);
  printf("Hardest Program: %s\n", student.hardest_program);
  /* %s is for substituting a character array */

  printf ("Short Term Life Goals: \n%s\n\n", student.s_goals);
  
  printf("Mid Term Life Goals: \n%s\n\n", student.m_goals);

  printf ("Long Term Life Goals:\n%s\n\n", student.lt_goals);

  return 0; /* 0 is typically returned when no errors have occurred */
}
