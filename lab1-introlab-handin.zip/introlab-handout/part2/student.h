/* student.h */
/* define a struct for storing student information */

struct student_info {

   int lucky_number; /*stores your lucky number*/
   char name[100];
   char birthplace[100];
   int semesters;
   char class_goal[500];
   char reason_cs[500];
   char hardest_program[500];
   char hobby[500];
   char s_goals[500]; /* 500 characters should be more than enough, right? */

   char m_goals[500];

   char lt_goals[500]; 
};

/* this is a function prototype, the function itself is in student.c */
struct student_info make_student(void);

