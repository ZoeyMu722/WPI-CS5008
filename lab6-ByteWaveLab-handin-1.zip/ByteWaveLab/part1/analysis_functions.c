#include <stdio.h>
#include <stdlib.h>
#include "analysis_functions.h"

int load_data(int numRows, int numCol, int teamData[][numCol], const char* fileName) {
    FILE *fp = fopen(fileName, "r");
    if (!fp) {
        printf("Error: cannot open file %s\n", fileName);
        exit(1);
    }

    char buffer[100];
    int year;
    fscanf(fp, "Year: %d\n", &year);

    for (int i = 0; i < numRows; i++) {
        for (int j = 0; j < numCol; j++) {
            fscanf(fp, "%d", &teamData[i][j]);
        }
    }

    fclose(fp);
    return year;
}

void findTotals(int numTeams, int totals[], int dataRows, int dataCol, int team_data[][dataCol]) {
    for (int i = 0; i < numTeams; i++) totals[i] = 0;

    for (int i = 0; i < dataRows; i++) {
        int away = team_data[i][0];
        int home = team_data[i][1];
        int awayScore = team_data[i][2];
        int homeScore = team_data[i][3];

        totals[away-1] += awayScore;
        totals[home-1] += homeScore;
    }
}

void findWins(int numTeams, int wins[], int dataRows, int dataCol, int team_data[][dataCol]) {
    for (int i = 0; i < numTeams; i++) wins[i] = 0;

    for (int i = 0; i < dataRows; i++) {
        int away = team_data[i][0];
        int home = team_data[i][1];
        int awayScore = team_data[i][2];
        int homeScore = team_data[i][3];

        if (awayScore > homeScore) wins[away-1]++;
        else if (homeScore > awayScore) wins[home-1]++;
        else {  // tie
            wins[away-1]++;
            wins[home-1]++;
        }
    }
}

int findWinner(int numTeams, int wins[], int totals[]) {
    int bestTeam = 1;
    for (int i = 1; i < numTeams; i++) {
        if (wins[i] > wins[bestTeam-1] ||
            (wins[i] == wins[bestTeam-1] && totals[i] > totals[bestTeam-1])) {
            bestTeam = i+1;
        }
    }
    return bestTeam;
}

