#include <stdio.h>
#include <stdlib.h>
#include "analysis_functions.h"

#define NUM_TEAMS 10
#define NUM_GAMES 45
#define NUM_COLS 4

int main(int argc, char* argv[]) {
    if (argc < 3) {
        printf("Run the program with a list of input file, followed by the output file\n");
        printf("./runScores file_name.txt ... results.txt\n");
        return 1;
    }

    int numInputFiles = argc - 2;
    char* outputFile = argv[argc-1];

    FILE* fout = fopen(outputFile, "w");
    if (!fout) {
        printf("Error: cannot open output file %s\n", outputFile);
        return 1;
    }

    // Header
    fprintf(fout, "Team");
    for (int i = 0; i < numInputFiles; i++) {
        fprintf(fout, " Year%d", i+1);
    }
    for (int i = 0; i < numInputFiles; i++) {
        fprintf(fout, " Points%d", i+1);
    }
    fprintf(fout, "\n");

    int winsPerFile[numInputFiles][NUM_TEAMS];
    int totalsPerFile[numInputFiles][NUM_TEAMS];
    int years[numInputFiles];

    for (int f = 0; f < numInputFiles; f++) {
        int teamData[NUM_GAMES][NUM_COLS];
        years[f] = load_data(NUM_GAMES, NUM_COLS, teamData, argv[f+1]);

        findTotals(NUM_TEAMS, totalsPerFile[f], NUM_GAMES, NUM_COLS, teamData);
        findWins(NUM_TEAMS, winsPerFile[f], NUM_GAMES, NUM_COLS, teamData);

        int winner = findWinner(NUM_TEAMS, winsPerFile[f], totalsPerFile[f]);
        printf("The top team of %d was Team %d.\n", years[f], winner);
    }

    for (int t = 0; t < NUM_TEAMS; t++) {
        fprintf(fout, "%d ", t+1);
        for (int f = 0; f < numInputFiles; f++) {
            fprintf(fout, "%d ", winsPerFile[f][t]);
        }
        for (int f = 0; f < numInputFiles; f++) {
            fprintf(fout, "%d ", totalsPerFile[f][t]);
        }
        fprintf(fout, "\n");
    }

    fclose(fout);
    return 0;
}

