#ifndef ANALYSIS_FUNCTIONS_H
#define ANALYSIS_FUNCTIONS_H

// Loads data from file into a 2D array, returns year
int load_data(int numRows, int numCol, int teamData[][numCol], const char* fileName);

// Calculates total scores
void findTotals(int numTeams, int totals[], int dataRows, int dataCol, int team_data[][dataCol]);

// Calculates wins
void findWins(int numTeams, int wins[], int dataRows, int dataCol, int team_data[][dataCol]);

// Finds winner (returns team number)
int findWinner(int numTeams, int wins[], int totals[]);

#endif

