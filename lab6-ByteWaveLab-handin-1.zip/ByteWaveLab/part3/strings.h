#ifndef STRINGS_H
#define STRINGS_H

char* left(const char* s, int len);
char* right(const char* s, int len);
char* mid(const char* s, int offset, int len);

#endif
