#include <stdio.h>
#include <stdlib.h>


int str_length(const char *s) {
    int len = 0;
    while (s[len] != '\0') {
        len++;
    }
    return len;
}


char* left(const char* s, int len) {
    if (len < 0) return NULL;  
    char* result = (char*)malloc((len + 1) * sizeof(char));
    if (!result) return NULL;

    int i;
    for (i = 0; i < len && s[i] != '\0'; i++) {
        result[i] = s[i];
    }
    result[i] = '\0'; 
    return result;
}



char* right(const char* s, int len) {
    int strLen = str_length(s);
    if (len > strLen) len = strLen;

    char* result = (char*)malloc((len + 1) * sizeof(char));
    if (!result) return NULL;

    int start = strLen - len;
    for (int i = 0; i < len; i++) {
        result[i] = s[start + i];
    }
    result[len] = '\0';
    return result;
}


char* mid(const char* s, int offset, int len) {
    int strLen = str_length(s);
    if (offset <= 0 || offset > strLen) return NULL;

    int start = offset - 1;  

    if (start + len > strLen) len = strLen - start;

    char* result = (char*)malloc((len + 1) * sizeof(char));
    if (!result) return NULL;

    for (int i = 0; i < len; i++) {
        result[i] = s[start + i];
    }
    result[len] = '\0';
    return result;
}

