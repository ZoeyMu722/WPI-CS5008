#include <stdio.h>
#include <stdlib.h>
#include <string.h>   // for strcmp
#include <assert.h>
#include "strings.h"

int main() {
    char string[] = "Once upon a time, there was a string";

    // Original test cases (typical usage)
    char* l = left(string, 16);
    char* r = right(string, 18);
    char* m = mid(string, 13, 11);

    printf("Original string: %s\n", string);
    printf("Left 16 characters: %s\n", l);
    printf("Right 18 characters: %s\n", r);
    printf("Middle 11 characters: %s\n", m);

    free(l);
    free(r);
    free(m);

    
    char empty[] = "";
   
    char* result = left(empty, 5);
    assert(result != NULL && strcmp(result, "") == 0);
    free(result);
 
    result = right(empty, 5);
    assert(result != NULL && strcmp(result, "") == 0);
    free(result);
   
    result = mid(empty, 1, 5);
    assert(result == NULL);
    

    
    result = left(string, 0);
    assert(result != NULL && strcmp(result, "") == 0);
    free(result);
    
    result = right(string, 0);
    assert(result != NULL && strcmp(result, "") == 0);
    free(result);

    result = mid(string, 5, 0);
    assert(result != NULL && strcmp(result, "") == 0);
    free(result);

    
    result = left(string, 50);
    assert(result != NULL && strcmp(result, string) == 0);
    free(result);
   
    result = right(string, 50);
    assert(result != NULL && strcmp(result, string) == 0);
    free(result);
    
    result = mid(string, 5, 50);
    assert(result != NULL && strcmp(result, string + 4) == 0);
    free(result);

    
    result = mid(string, -1, 5);
    assert(result == NULL);
    
    result = mid(string, 0, 5);
    assert(result == NULL);
    
    result = mid(string, 36, 5);
    assert(result != NULL && strcmp(result, "g") == 0);
    free(result);
  
    result = mid(string, 37, 5);
    assert(result == NULL);

    
    result = left(string, -5);
    assert(result == NULL);
    
    result = right(string, -5);
    assert(result == NULL);
 
    result = mid(string, 5, -5);
    assert(result == NULL);

  
    result = left(string, 36);
    assert(result != NULL && strcmp(result, string) == 0);
    free(result);
    
    result = right(string, 36);
    assert(result != NULL && strcmp(result, string) == 0);
    free(result);
   
    result = mid(string, 1, 36);
    assert(result != NULL && strcmp(result, string) == 0);
    free(result);
    
    result = mid(string, 25, 12);
    assert(result != NULL && strcmp(result, "was a string") == 0);
    free(result);

    printf("All tests passed.\n");
    return 0;
}
