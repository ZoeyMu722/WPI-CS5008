Hello Linux: learning the basics of bash shell

This part of the lab demonstrates basic Linux commands for working with files and directories.

Commands covered include:
- Creating and editing files with nano
- Viewing file contents with cat
- Copying files with cp
- Moving or renaming files with mv
- Deleting files with rm
- Downloading files from the Internet using wget
- Viewing command output using head, tail, less, grep
- I/O redirection and pipes

In this lab, you will create a file called newfile.txt, add some text to it, and manipulate it
using the above commands. You will also download a file from the Internet (README.txt) 
and practice basic file operations.

