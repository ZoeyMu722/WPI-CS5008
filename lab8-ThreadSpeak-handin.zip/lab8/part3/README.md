# CS5008 Lab 8 – Part 3: Family Database (Linked List Implementation)

## Overview
This program implements a **menu-driven Family Database** using a **singly linked list** in C.  

Each record contains:
- `name` (string)
- `relationship` (string)
- `age` (integer)

The user can interact through simple commands:

[A] Add   [D] Delete   [L] List   [O] Open   [S] Save   [Q] Quit



## How to Compile & Run

### Compile
make

### Run
./family

### Or use:
make run

### Clean up compiled files
make clean



## Features Implemented
| Feature | Description |
|----------|-------------|
| **Add Record (A)** | Dynamically allocates memory for a new family member and adds it to the linked list. |
| **Delete Record (D)** | Searches by name, handles deletion of head/middle/tail nodes, and frees memory. |
| **List Records (L)** | Displays all family members in a formatted table. |
| **Open (O)** | Loads saved family data from a text file (`family.txt`). |
| **Save (S)** | Saves all current records to `family.txt` in CSV format. |
| **Quit (Q)** | Frees all allocated nodes and exits safely. |



## Data File Format
Records are saved in **family.txt** in the following comma-separated format:
name,relationship,age



**Example:**
Alice,Sister,22
John,Father,54
Lucy,Mother,50



## Example Run
=== Family Database ===
[A] Add  [D] Delete  [L] List  [O] Open  [S] Save  [Q] Quit

Enter choice: A
Enter name: Alice
Enter relationship: Sister
Enter age: 22
Record added successfully!

Enter choice: L
Name                 Relationship   Age
-------------------------------------------
Alice                Sister         22



## File List

| File | Purpose |
|------|----------|
| `family.c` | Main program source code |
| `Makefile` | Build script |
| `README.md` | Documentation and usage guide |
| `prompts_reflection.pdf` | AI Prompts and Reflection write-up |
| `family.txt` | Optional data file for saved records |



## Notes
- Program uses **dynamic memory allocation** for each record (`malloc()` and `free()`).
- Uses **file I/O** (`fopen`, `fprintf`, `fgets`, `sscanf`) for saving/loading records.
- Tested in the **WPI CS Department Linux VM environment**.
- Be sure to run `make clean` before zipping for submission.
