#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SIZE 50
#define FILENAME "family.txt"


typedef struct family {
    char name[SIZE];
    char relationship[SIZE];
    int age;
    struct family *next;
} Family;


void addRecord(Family **head);
void deleteRecord(Family **head);
void listRecords(Family *head);
void saveToFile(Family *head);
void loadFromFile(Family **head);
void freeList(Family **head);

int main() {
    Family *head = NULL;
    char choice;

    printf("=== Family Database ===\n");
    printf("[A] Add  [D] Delete  [L] List  [O] Open  [S] Save  [Q] Quit\n");

    while (1) {
        printf("\nEnter choice: ");
        scanf(" %c", &choice);
        getchar(); 

        switch (choice) {
            case 'A':
            case 'a':
                addRecord(&head);
                break;
            case 'D':
            case 'd':
                deleteRecord(&head);
                break;
            case 'L':
            case 'l':
                listRecords(head);
                break;
            case 'O':
            case 'o':
                loadFromFile(&head);
                break;
            case 'S':
            case 's':
                saveToFile(head);
                break;
            case 'Q':
            case 'q':
                freeList(&head);
                printf("Goodbye!\n");
                return 0;
            default:
                printf("Invalid option.\n");
        }
    }
}


void addRecord(Family **head) {
    Family *newNode = (Family *)malloc(sizeof(Family));
    if (!newNode) {
        printf("Memory allocation failed!\n");
        return;
    }

    printf("Enter name: ");
    fgets(newNode->name, SIZE, stdin);
    newNode->name[strcspn(newNode->name, "\n")] = '\0';

    printf("Enter relationship: ");
    fgets(newNode->relationship, SIZE, stdin);
    newNode->relationship[strcspn(newNode->relationship, "\n")] = '\0';

    printf("Enter age: ");
    scanf("%d", &newNode->age);
    getchar();

    newNode->next = *head;
    *head = newNode;

    printf("Record added successfully!\n");
}


void deleteRecord(Family **head) {
    if (*head == NULL) {
        printf("No records to delete.\n");
        return;
    }

    char name[SIZE];
    printf("Enter name to delete: ");
    fgets(name, SIZE, stdin);
    name[strcspn(name, "\n")] = '\0';

    Family *temp = *head, *prev = NULL;

    while (temp != NULL && strcmp(temp->name, name) != 0) {
        prev = temp;
        temp = temp->next;
    }

    if (temp == NULL) {
        printf("Record not found.\n");
        return;
    }

    if (prev == NULL)
        *head = temp->next;  
    else
        prev->next = temp->next;

    free(temp);
    printf("Record deleted successfully.\n");
}


void listRecords(Family *head) {
    if (head == NULL) {
        printf("No records found.\n");
        return;
    }

    printf("\n%-20s %-15s %-5s\n", "Name", "Relationship", "Age");
    printf("-------------------------------------------\n");

    Family *temp = head;
    while (temp != NULL) {
        printf("%-20s %-15s %-5d\n", temp->name, temp->relationship, temp->age);
        temp = temp->next;
    }
}


void saveToFile(Family *head) {
    FILE *fp = fopen(FILENAME, "w");
    if (!fp) {
        perror("Error opening file");
        return;
    }

    Family *temp = head;
    while (temp != NULL) {
        fprintf(fp, "%s,%s,%d\n", temp->name, temp->relationship, temp->age);
        temp = temp->next;
    }

    fclose(fp);
    printf("Data saved to %s\n", FILENAME);
}


void loadFromFile(Family **head) {
    FILE *fp = fopen(FILENAME, "r");
    if (!fp) {
        perror("Error opening file");
        return;
    }

    freeList(head); 

    char line[200];
    while (fgets(line, sizeof(line), fp)) {
        Family *newNode = (Family *)malloc(sizeof(Family));
        sscanf(line, "%49[^,],%49[^,],%d", newNode->name, newNode->relationship, &newNode->age);
        newNode->next = *head;
        *head = newNode;
    }

    fclose(fp);
    printf("Data loaded from %s\n", FILENAME);
}


void freeList(Family **head) {
    Family *temp;
    while (*head) {
        temp = *head;
        *head = (*head)->next;
        free(temp);
    }
}
