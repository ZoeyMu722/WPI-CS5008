#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <errno.h>

typedef struct {
    int read_fd;
    int write_fd;
    const char *msg;
} pipe_ctx_t;

void *writer_thread(void *arg) {
    pipe_ctx_t *ctx = (pipe_ctx_t *)arg;
    size_t len = strlen(ctx->msg);
    ssize_t n = write(ctx->write_fd, ctx->msg, len);
    if (n < 0) {
        perror("write");
        pthread_exit((void*)1);
    }
   
    if (close(ctx->write_fd) == -1) {
        perror("close write_fd");
        pthread_exit((void*)1);
    }
    return NULL;
}


void *reader_thread(void *arg) {
    pipe_ctx_t *ctx = (pipe_ctx_t *)arg;
    char buf[1024];
    ssize_t n = read(ctx->read_fd, buf, sizeof(buf)-1);
    if (n < 0) {
        perror("read");
        pthread_exit((void*)1);
    }
    buf[n] = '\0'; 
    printf("[Reader] Received: %s\n", buf);
    if (close(ctx->read_fd) == -1) {
        perror("close read_fd");
        pthread_exit((void*)1);
    }
    return NULL;
}

int main(void) {
    int fds[2];
    if (pipe(fds) == -1) {
        perror("pipe");
        return 1;
    }

    char input[512];
    printf("Enter a message to send (default: 'Hello from writer thread!'):\n> ");
    fflush(stdout);
    if (!fgets(input, sizeof(input), stdin)) {
      
        strcpy(input, "Hello from writer thread!\n");
    }
   
    size_t L = strlen(input);
    if (L && input[L-1] == '\n') input[L-1] = '\0';

    pipe_ctx_t ctx;
    ctx.read_fd = fds[0];
    ctx.write_fd = fds[1];
    ctx.msg = input[0] ? input : "Hello from writer thread!";

    pthread_t tw, tr;
   
    if (pthread_create(&tr, NULL, reader_thread, &ctx) != 0) {
        perror("pthread_create reader");
        return 1;
    }
    if (pthread_create(&tw, NULL, writer_thread, &ctx) != 0) {
        perror("pthread_create writer");
        return 1;
    }

   
    void *rv1; void *rv2;
    pthread_join(tw, &rv1);
    pthread_join(tr, &rv2);

    printf("Press Enter to exit...");
    int c;
    
    while ((c = getchar()) != '\n' && c != EOF) {}
    return 0;
}
