#define _POSIX_C_SOURCE 200809L
#include "tale_functions.h"

#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <unistd.h>


static void rstrip(char *s) {
    size_t n = strlen(s);
    while (n && (s[n-1] == '\n' || s[n-1] == '\r' || isspace((unsigned char)s[n-1]))) {
        s[--n] = '\0';
    }
}
static void lstrip_inplace(char *s) {
    size_t i = 0, j = 0, n = strlen(s);
    while (i < n && isspace((unsigned char)s[i])) i++;
    if (i == 0) return;
    while (i < n) s[j++] = s[i++];
    s[j] = '\0';
}
static int is_blank_or_comment(const char *s) {
    for (; *s; ++s) {
        if (!isspace((unsigned char)*s)) return 0;
    }
    return 1;
}


int read_command(FILE *fp, char *command, size_t max_len) {
    while (fgets(command, (int)max_len, fp)) {
        rstrip(command);
        lstrip_inplace(command);
        if (command[0] == '\0') continue;           
        if (strncmp(command, "#", 1) == 0) continue; 
        return 1; 
    }
    return 0; // EOF
}


int create_output_files(pid_t pid, int *stdout_fd, int *stderr_fd) {
    char out_name[64], err_name[64];
    snprintf(out_name, sizeof(out_name),  "%d.out", pid);
    snprintf(err_name, sizeof(err_name),  "%d.err", pid);

    int fd_out = open(out_name, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (fd_out < 0) return -1;

    int fd_err = open(err_name, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (fd_err < 0) {
        close(fd_out);
        return -1;
    }

    *stdout_fd = fd_out;
    *stderr_fd = fd_err;
    return 0;
}


int setup_io_redirection(pid_t pid) {
    int fd_out = -1, fd_err = -1;
    if (create_output_files(pid, &fd_out, &fd_err) < 0) {
        return -1;
    }


    if (dup2(fd_out, STDOUT_FILENO) < 0) {
        close(fd_out); close(fd_err);
        return -1;
    }
    if (dup2(fd_err, STDERR_FILENO) < 0) {
        close(fd_out); close(fd_err);
        return -1;
    }
    
    close(fd_out);
    close(fd_err);
    return 0;
}


int execute_command(const char *command) {
    pid_t pid = fork();
    if (pid < 0) {
       
        return -1;
    } else if (pid == 0) {
       
        pid_t cpid = getpid();
        if (setup_io_redirection(cpid) < 0) {
            
            _exit(127);
        }
        
        execl("/bin/sh", "sh", "-c", command, (char *)NULL);
        
        _exit(127);
    } else {
      
        int status = 0;
        if (waitpid(pid, &status, 0) < 0) {
            return -1;
        }
        if (WIFEXITED(status)) return WEXITSTATUS(status);
        if (WIFSIGNALED(status)) return 128 + WTERMSIG(status); 
        return 0;
    }
}


static void ctime_trim(const time_t *t, char *buf, size_t n) {
  
    const char *p = ctime(t);
    if (!p) { snprintf(buf, n, ""); return; }
    snprintf(buf, n, "%s", p);
    size_t L = strlen(buf);
    if (L && buf[L-1] == '\n') buf[L-1] = '\0';
}

void log_execution(FILE *log_fp, const char *command, time_t start_time, time_t end_time) {
    char start_buf[64], end_buf[64];
    ctime_trim(&start_time, start_buf, sizeof(start_buf));
    ctime_trim(&end_time,   end_buf,   sizeof(end_buf));

    
    fprintf(log_fp, "%s\t%s\t%s\n", command, start_buf, end_buf);
    fflush(log_fp);
}


void cleanup_process_files(pid_t pid) {
    (void)pid;
    
}

