#ifndef TALE_FUNCTIONS_H
#define TALE_FUNCTIONS_H

#include <stdio.h>
#include <sys/types.h>
#include <time.h>

// Core process management
int  read_command(FILE *fp, char *command, size_t max_len);
int  execute_command(const char *command);
void log_execution(FILE *log_fp, const char *command, time_t start_time, time_t end_time);

// I/O redirection
int  setup_io_redirection(pid_t pid);
int  create_output_files(pid_t pid, int *stdout_fd, int *stderr_fd);
void cleanup_process_files(pid_t pid); // 这里实现为占位，可按需扩展

#endif
