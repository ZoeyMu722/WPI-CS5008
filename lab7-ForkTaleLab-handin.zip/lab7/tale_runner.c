#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "tale_functions.h"

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <input_file>\n", argv[0]);
        return 1;
    }

    const char *input_path = argv[1];
    FILE *fp = fopen(input_path, "r");
    if (!fp) {
        perror("fopen input");
        return 1;
    }

    FILE *log_fp = fopen("output.log", "a");
    if (!log_fp) {
        perror("fopen output.log");
        fclose(fp);
        return 1;
    }

    char line[4096];
    while (read_command(fp, line, sizeof(line))) {
        time_t start_time = time(NULL);
        int status = execute_command(line);
        time_t end_time   = time(NULL);

        // 记录时间线
        log_execution(log_fp, line, start_time, end_time);

        // 可选：将退出状态也打印到对应的 <pid>.err 里（这里不需要，子进程各自输出）
        (void)status;
    }

    fclose(log_fp);
    fclose(fp);
    return 0;
}
