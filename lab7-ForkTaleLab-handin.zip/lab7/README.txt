# ForkTale

## Build
make

## Run
./tale_runner input.txt

- input.txt: One command per line (can contain built-in commands/pipelines, etc., since it's executed using /bin/sh -c)
- For each child process:
- Standard output -> <pid>.out
- Standard error -> <pid>.err
- General log: output.log (command_start_time_end_time)

Example input.txt:
uname -a
cd /home/
ps aux

